
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="{{ asset('admin/assets/vendor/global/global.min.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor/chart.js/Chart.bundle.min.js') }}"></script>
    <script src="{{ asset('admin/assets/js/custom.min.js') }}"></script>
	<script src="{{ asset('admin/assets/js/deznav-init.js') }}"></script>
	
	<!-- Apex Chart -->
	<script src="{{ asset('admin/assets/vendor/apexchart/apexchart.js') }}"></script>
	
	<!-- Dashboard 1 -->
	<script src="{{ asset('admin/assets/js/dashboard/dashboard-1.js') }}"></script>

	<script src="{{ asset('admin/assets/js/backend/burger.js') }}"></script>

	<script src="{{ asset('admin/assets/js/backend/backend.js') }}"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	