<!DOCTYPE html>
<html>

<!-- Mirrored from gico.io/cyyo/04_Burger/menu-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Nov 2021 19:37:31 GMT -->
<head>
<meta charset="utf-8">
<title>Cyyo Multipurpose HTML-5 Template | Menu 02</title>
<!-- Stylesheets -->
<link href="<?php echo e(asset('front/assets/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('front/assets/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('front/assets/css/responsive.css')); ?>" rel="stylesheet">

<link href="front/assets/https://fonts.googleapis.com/css2?family=Berkshire+Swash&amp;family=Overpass:wght@100;200;300;400;600;700;800;900&amp;family=Vast+Shadow&amp;display=swap" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo e(asset('front/assets/images/favicon.png')); ?>" type="image/x-icon">
<link rel="icon" href="<?php echo e(asset('front/assets/images/favicon.png')); ?>" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<!--[if lt IE 9]><script src="front/assets/https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="front/assets/js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
 	<!-- Main Header-->
    <header class="main-header header-style-one">
    	
		<!-- Header Upper -->
        <div class="header-upper">
        	<div class="outer-container clearfix">
            	<!-- Phone Box -->
				<div class="phone-box">
					Call now:<br>
					<a class="phone" href="front/assets/tel:+880168-123-48101">880168 - 123 48101</a>
				</div>
				
				<div class="nav-outer clearfix">
					<!--Mobile Navigation Toggler-->
					<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
					<!-- Main Menu -->
					<nav class="main-menu navbar-expand-md">
						<div class="navbar-header">
							<!-- Toggle Button -->    	
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						
						<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
							<ul class="navigation clearfix">
								<li><a href="front/assets/index.html">Home</a></li>
								<li><a href="front/assets/about.html">About Us</a></li>
								<li><a href="front/assets/services.html">Services</a></li>
								<li class="current dropdown"><a href="front/assets/#">Menu</a>
									<ul>
										<li><a href="front/assets/menu.html">Menu</a></li>
										<li><a href="front/assets/menu-2.html">Menu 02</a></li>
										<li><a href="front/assets/menu-3.html">Menu 03</a></li>
										<li><a href="front/assets/book-table.html">Book Table</a></li>
										<li><a href="front/assets/menu-detail.html">Menu Detail</a></li>
									</ul>
								</li>
								<li class="dropdown"><a href="front/assets/#">Blog</a>
									<ul>
										<li><a href="front/assets/blog.html">Our Blog</a></li>
										<li><a href="front/assets/blog-detail.html">Blog Single</a></li>
										<li><a href="front/assets/not-found.html">Not Found</a></li>
									</ul>
								</li>
								<li><a href="front/assets/contact.html">Contact us</a></li>
							</ul>
						</div>
					</nav>
					
					<!-- Main Menu End-->
					<div class="outer-box clearfix">
						
						<!-- Cart Box -->
						<div class="cart-box">
							<div class="dropdown">
								<button class="cart-box-btn dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flaticon-shopping-cart"></span><span class="total-cart">2</span></button>
								<div class="dropdown-menu pull-right cart-panel" aria-labelledby="dropdownMenu1">

									<div class="cart-product">
										<div class="inner">
											<div class="cross-icon"><span class="icon fa fa-remove"></span></div>
											<div class="image"><img src="front/assets/images/resource/post-thumb-1.jpg" alt="" /></div>
											<h3><a href="front/assets/#">Flying Ninja</a></h3>
											<div class="quantity-text">Quantity 1</div>
											<div class="price">$99.00</div>
										</div>
									</div>
									<div class="cart-product">
										<div class="inner">
											<div class="cross-icon"><span class="icon fa fa-remove"></span></div>
											<div class="image"><img src="front/assets/images/resource/post-thumb-2.jpg" alt="" /></div>
											<h3><a href="front/assets/#">Patient Ninja</a></h3>
											<div class="quantity-text">Quantity 1</div>
											<div class="price">$99.00</div>
										</div>
									</div>
									<div class="cart-total">Sub Total: <span>$198</span></div>
									<ul class="btns-boxed">
										<li><a href="front/assets/#">View Cart</a></li>
										<li><a href="front/assets/#">CheckOut</a></li>
									</ul>

								</div>
							</div>
						</div>
						
						<!-- Quote Btn -->
						<div class="btn-box">
							<a href="front/assets/contact.html" class="theme-btn btn-style-one"><span class="txt">Booking Now</span></a>
						</div>
							
					</div>
				</div>
				
            </div>
        </div>
        <!--End Header Upper-->
        
		<!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="front/assets/index.html" title=""><img src="front/assets/images/logo-small.png" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav><!-- Main Menu End-->
					
					<!-- Main Menu End-->
					<div class="outer-box clearfix">
						
						<!-- Search Btn -->
						<div class="search-box-btn search-box-outer"><span class="icon fa fa-search"></span></div>
					
						<!-- Cart Box -->
						<div class="cart-box">
							<div class="dropdown">
								<button class="cart-box-btn dropdown-toggle" type="button" id="dropdownMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flaticon-shopping-bag-1"></span><span class="total-cart">2</span></button>
								<div class="dropdown-menu pull-right cart-panel" aria-labelledby="dropdownMenu">

									<div class="cart-product">
										<div class="inner">
											<div class="cross-icon"><span class="icon fa fa-remove"></span></div>
											<div class="image"><img src="front/assets/images/resource/post-thumb-1.jpg" alt="" /></div>
											<h3><a href="front/assets/#">Flying Ninja</a></h3>
											<div class="quantity-text">Quantity 1</div>
											<div class="price">$99.00</div>
										</div>
									</div>
									<div class="cart-product">
										<div class="inner">
											<div class="cross-icon"><span class="icon fa fa-remove"></span></div>
											<div class="image"><img src="front/assets/images/resource/post-thumb-2.jpg" alt="" /></div>
											<h3><a href="front/assets/#">Patient Ninja</a></h3>
											<div class="quantity-text">Quantity 1</div>
											<div class="price">$99.00</div>
										</div>
									</div>
									<div class="cart-total">Sub Total: <span>$198</span></div>
									<ul class="btns-boxed">
										<li><a href="front/assets/#">View Cart</a></li>
										<li><a href="front/assets/#">CheckOut</a></li>
									</ul>

								</div>
							</div>
						</div>
						
					</div>
					
                </div>
            </div>
        </div><!-- End Sticky Menu -->
    
		<!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-multiply"></span></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="front/assets/index.html"><img src="front/assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            </nav>
        </div><!-- End Mobile Menu -->
	
    </header>
    <!-- End Main Header -->
	
	<!-- Page Title -->
    <section class="page-title" style="background-image: url(images/background/4.jpg)">
		<div class="icon-layer-one" style="background-image: url(images/icons/icon-4.png)"></div>
		<div class="icon-layer-two" style="background-image: url(images/icons/icon-5.png)"></div>
    	<div class="auto-container">
			<h2>Our Menu</h2><br>
			<ul class="bread-crumbs">
				<li><a href="front/assets/index.html">Home</a></li>
				<li>Our Menu</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
	<!-- Catalog Section -->
	<section class="catalog-section" style="background-image: url(images/background/pattern-2.png)">
		<div class="icon-layer-one" style="background-image: url(images/icons/pattern-2.png)"></div>
		<div class="icon-layer-two" style="background-image: url(images/icons/pattern-2.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>Our Catalog</h2>
				<div class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</div>
			</div>
			<div class="row clearfix">
				
				<!-- Menu Block -->
				
			
				

				<?php $__currentLoopData = $burg_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="menu-block col-xl-3 col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<div class="price"><?php echo e($element -> price); ?> Tk</div>
							<a href="front/assets/menu-detail.html"><img src="<?php echo e(URL::to('')); ?>/media/burger/<?php echo e($element -> image); ?>" alt="" /></a>
						</div>
						<div class="lower-content">
							<h4><a href="front/assets/menu-detail.html"><?php echo e($element -> name); ?></a></h4>
							<div class="rating">
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<div class="available">Available</div>
							<div><a  href="#" id="buy_now_id" buy_now_attr="<?php echo e($element -> id); ?>" data-toggle="modal" data-target="#ordermodel" class="theme-btn btn-style-one"><span class="txt">Buy Now</span></a></div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- Menu Block -->
				<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="ordermodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       

        <form action="<?php echo e(route('order.control',$suidi -> id)); ?>" method="POST">
        	<?php echo csrf_field(); ?>
        	  <div class="form-group">
      <input type="text" class="form-control" name="quantity" placeholder="quantity">
      </div>
      <div class="form-group">
      <select class="custom-select" name="drinks">
  <option selected disabled>Open this select menu</option>
  <option value="Pepsi">Pepsi - 50 tk</option>
  <option value="CocaCola">CocaCola - 100 tk</option>
  <option value="Miranda">Miranda - 200 tk</option>
</select>

      </div>
      <div class="form-group">
      <input type="text" class="form-control" name="customer" placeholder="customer name">
      </div>
      <div class="form-group">
      <input type="text" class="form-control" name="phone" placeholder="phone">
      </div> 


      <div class="form-group">
       <h3>Total</h3>
      </div>



        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
				
				
			
				
			</div>
			
			<!-- Post Share Options -->
			<div class="styled-pagination text-center">
				<ul class="clearfix">
					<li class="active"><a href="front/assets/#">01</a></li>
					<li><a href="front/assets/#">02</a></li>
					<li><a href="front/assets/#">03</a></li>
					<li><a href="front/assets/#">04</a></li>
					<li class="next"><a href="front/assets/#"><span class="fa fa-angle-double-right"></span> </a></li>
				</ul>
			</div>
			
		</div>
	</section>
	<!-- End Catalog Section -->
	
	<!-- Clients Section -->
    <section class="clients-section">
		<div class="auto-container">
			<!-- Title Box -->
			<div class="title-box">
				<div class="icon-layer-one" style="background-image: url(images/background/pattern-5.png)"></div>
				<div class="circle-box"></div>
				<h2>“One of the best vegan restaurants <br> in world”</h2>
			</div>
			
			<div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/1.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/2.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/1.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/3.jpg" alt=""></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/4.jpg" alt=""></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/1.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/2.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/1.jpg" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/3.jpg" alt=""></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="front/assets/#"><img src="front/assets/images/clients/4.jpg" alt=""></a></figure></li>
                </ul>
            </div>
			
		</div>
	</section>
	<!-- End Clients Section -->
	
	<!-- Main Footer -->
    <footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(images/icons/pattern-3.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(images/icons/pattern-4.png)"></div>
		<div class="pattern-layer-three" style="background-image: url(images/icons/pattern-5.png)"></div>
		<div class="pattern-layer-four" style="background-image: url(images/icons/pattern-6.png)"></div>
    	<div class="auto-container">
			<div class="inner-container">
				
				<!-- Widgets Section -->
				<div class="widgets-section">
					<div class="row clearfix">
						
						<!-- Footer Column -->
						<div class="footer-column col-lg-3 col-md-6 col-sm-12">
							<div class="footer-widget logo-widget">
								<div class="logo">
									<a href="front/assets/index.html"><img src="front/assets/images/footer-logo.png" alt="" /></a>
								</div>
								<div class="text">Sebastian and Tony Lazzara221 W 38th St New York, NY 10018</div>
								<div class="phone"><a href="front/assets/tel:+212-924-7778">+(212) 924-7778</a></div>
								<!-- Social Box -->
								<ul class="social-box">
									<li><a href="front/assets/#" class="fa fa-facebook-f"></a></li>
									<li><a href="front/assets/#" class="fa fa-linkedin"></a></li>
									<li><a href="front/assets/#" class="fa fa-instagram"></a></li>
									<li><a href="front/assets/#" class="fa fa-twitter"></a></li>
								</ul>
							</div>
						</div>
						
						<!-- Footer Column -->
						<div class="footer-column col-lg-3 col-md-6 col-sm-12">
							<div class="footer-widget timine-widget">
								<h5>Opening Hours</h5>
								<ul class="time-list">
									<li>Friday:    09:00 – 23:00h</li>
									<li>Saturday:    09:00 – 16:00h</li>
									<li>Sunday:    12:00 – 18:00h</li>
								</ul>
							</div>
						</div>
						
						<!-- Footer Column -->
						<div class="footer-column col-lg-3 col-md-6 col-sm-12">
							<div class="footer-widget links-widget">
								<h5>Useful Link</h5>
								<ul class="list-link">
									<li><a href="front/assets/#">About us</a></li>
									<li><a href="front/assets/#">Membership</a></li>
									<li><a href="front/assets/#">Item</a></li>
									<li><a href="front/assets/#">Refund Policy</a></li>
									<li><a href="front/assets/#">Contact us</a></li>
									<li><a href="front/assets/#">Shop</a></li>
								</ul>
							</div>
						</div>
						
						<!-- Footer Column -->
						<div class="footer-column col-lg-3 col-md-6 col-sm-12">
							<div class="footer-widget links-widget">
								<h5>Useful Link</h5>
								<ul class="list-link">
									<li><a href="front/assets/#">Analytics</a></li>
									<li><a href="front/assets/#">Activity</a></li>
									<li><a href="front/assets/#">Content</a></li>
									<li><a href="front/assets/#">Management</a></li>
									<li><a href="front/assets/#">Wishlist</a></li>
								</ul>
							</div>
						</div>
							
					</div>
				</div>
				
				<!-- Subscribe Box -->
				<div class="subscribe-box">
					<div class="text">Sign up with your email address to receive news and updates</div>
					<!-- Newsletter Form -->
					<div class="newsletter-form">
						<form method="post" action="https://gico.io/cyyo/04_Burger/contact.html">
							<div class="form-group">
								<input type="email" name="email" value="" placeholder="Email" required="">
								<button type="submit" class="theme-btn"><span class="txt">Subscribe</span></button>
							</div>
						</form>
					</div>
				</div>
				
			</div>
			
		</div>
		
		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="auto-container">
				<div class="clearfix">
					<div class="pull-left">
						<div class="copyright">Copyright &copy;2021 <a href="front/assets/#">All rights reserved</a></div>
					</div>
					<div class="pull-right">
						<div class="cards"><img src="front/assets/images/icons/cards.png" alt="" /></div>
					</div>
				</div>
			</div>
		</div>
		
	</footer>
	<!-- End Main Footer -->
	
</div>
<!--End pagewrapper-->

<!-- Search Popup -->
<div class="search-popup">
	<button class="close-search style-two"><span class="flaticon-multiply"></span></button>
	<button class="close-search"><span class="flaticon-multiply"></span></button>
	<form method="post" action="https://gico.io/cyyo/04_Burger/blog.html">
		<div class="form-group">
			<input type="search" name="search-field" value="" placeholder="Search Here" required="">
			<button type="submit"><i class="fa fa-search"></i></button>
		</div>
	</form>
</div>
<!-- End Header Search -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="<?php echo e(asset('front/assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/tilt.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/jquery.paroller.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/timepicker.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/nav-tool.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('front/assets/js/myscript.js')); ?>"></script>

</body>

<!-- Mirrored from gico.io/cyyo/04_Burger/menu-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Nov 2021 19:37:31 GMT -->
</html><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/front/main.blade.php ENDPATH**/ ?>