    

   


    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(URL::to('')); ?>/admin/myicon.png">
    <link href="<?php echo e(asset('admin/assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/assets/css/custom.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('admin/assets/../../cdn.lineicons.com/2.0/LineIcons.css')); ?>" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/layouts/partials/css.blade.php ENDPATH**/ ?>