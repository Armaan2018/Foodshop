

<?php $__env->startSection('main-content'); ?>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#insertmodel">
Create A New Burger !!
</button>






<div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">All Created Burgers</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md">
                                        <thead class="thead-dark">
                                            <tr>
                                                
                                                <th><strong>ID NO.</strong></th>
                                                <th><strong>Price</strong></th>
                                                <th width="15%"><strong>Size | Quantity | total</strong></th>
                                                
                                                <th><strong>Snacks</strong></th>           
                                                <th width="10%"><strong>Sancks Quantity|Price</strong></th>
                                                <th><strong>Snacks</strong></th>
                                                <th width="10%"><strong>Drinks Quantity|Price</strong></th>
                                                <th><strong>Total</strong></th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $buri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                           
                                                <?php
                                                   $dam = json_decode($element -> burger);
                                                   $dam_san = json_decode($element -> snacks); 

                                                   $dam_dri = json_decode($element -> drinks);
                                                ?>
                                                 <td><?php echo e($dam -> burgername); ?></td>
                                                 <td><strong><?php echo e($dam -> burgerprice); ?></strong></td>
                                                  <td><strong><?php echo e($dam -> burgquantity); ?> | <?php echo e($dam -> burgsize); ?> | <?php echo e($dam -> total); ?></strong></td>
                                                <td><strong><?php echo e($dam_san -> snack_name); ?></strong></td>


                                                <td><strong><?php echo e($dam_san -> snack_bill); ?> * <?php echo e($dam_san -> snack_quantity); ?> = <?php echo e($dam_san -> snacks_bill); ?> </strong></td> 



                                                <td><strong><?php echo e($dam_dri -> drinkname); ?></strong></td>

                                                <td><strong><?php echo e($dam_dri -> drinkprice); ?>  <?php echo e($dam_dri -> drinksize); ?>  <?php echo e($dam_dri -> drinkquan); ?> <?php echo e($dam_dri -> totaldrink); ?> </strong></td>
                                                <td><strong><?php echo e($element -> total); ?></strong></td>
                                                </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                               


                                           
                               
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>















<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/test.blade.php ENDPATH**/ ?>