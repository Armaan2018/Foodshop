 <div class="nav-header">
            <a href="{{ route('dashboard') }}" class="brand-logo">
                <img class="logo-abbr" src="{{URL::to('')}}/admin/myicon.png" alt="">
                <img class="logo-compact" src="{{URL::to('')}}/admin/myicon.png" alt="">
                <h2 class="p-3 mt-2"><strong class="text-white">BURG-E</strong></h2>
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>