

<?php $__env->startSection('main-content'); ?>







<div class="col-xl-12 col-xxl-12 col-lg-12 col-sm-12" id="promark">
                        <div class="card">
                            <div class="card-header border-0">
                                <div>
                                    <h4 class="card-title mb-2">Recent Order Request</h4>
                                    <p class="fs-13 mb-0">All Orders Details Here</p>
                                </div>
                                <div class="dropdown">
                                    <a href="<?php echo e(route('confirm.show.orders')); ?>" class="btn border btn-rounded text-black">
                                        Completed Order
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive ">
                                    <table class="table order-request">
                                        <tbody id="order_table_tbody">

                                         
                                       
                                       
                                    </tbody>
                                  </table>
                                   
                                </div>
                            </div>
                        </div>
                    </div>









<!-- Modal -->







    <script>
        function autoRefresh() {
            window.location = window.location.href;
        }
        setInterval('autoRefresh()', 30000);
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/order.blade.php ENDPATH**/ ?>