
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('admin/assets/vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/deznav-init.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('admin/assets/vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('admin/assets/js/dashboard/dashboard-1.js')); ?>"></script>

	<script src="<?php echo e(asset('admin/assets/js/backend/burger.js')); ?>"></script>

	<script src="<?php echo e(asset('admin/assets/js/backend/backend.js')); ?>"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/layouts/partials/js.blade.php ENDPATH**/ ?>