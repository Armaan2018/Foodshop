  <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed  By Dexizone &amp; Developed by <a href="" target="_blank">Armaan</a> 2021</p>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>