 <div class="nav-header">
            <a href="<?php echo e(route('dashboard')); ?>" class="brand-logo">
                <img class="logo-abbr" src="<?php echo e(URL::to('')); ?>/admin/myicon.png" alt="">
                <img class="logo-compact" src="<?php echo e(URL::to('')); ?>/admin/myicon.png" alt="">
                <h2 class="p-3 mt-2"><strong class="text-white">BURG-E</strong></h2>
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\BurgerHouse\resources\views/admin/layouts/header-nav.blade.php ENDPATH**/ ?>